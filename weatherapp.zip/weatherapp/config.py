API_KEY = "07a6d919910492c8597ae488f5a36c6d"
BASE_URL = "https://api.openweathermap.org/data/2.5/weather"
