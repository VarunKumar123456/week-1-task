print("✅ main.py is running...")  # Debugging

from src.ui import main

if __name__ == "__main__":
    print("✅ Calling main() from ui.py...")
    main()
